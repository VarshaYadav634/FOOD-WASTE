<?php  
$con = mysqli_connect("localhost", "root", "", "mydb");  
if (!$con) {  
    die('Could not connect: ' . mysqli_connect_error());  
}  

$sql = "INSERT INTO logintable (name, phone, street, district, state, pincode)    
VALUES  ('$_POST[name]', '$_POST[phone]', '$_POST[street]', '$_POST[district]', '$_POST[state]', '$_POST[pincode]')";  

if (!mysqli_query($con, $sql)) {  
    die('Error: ' . mysqli_error($con));  
}  

// Close the connection
mysqli_close($con);  

// Redirect to paymentgateway.html
header("Location: paymentgateway.html");
exit(); // Ensure no further code is executed after the redirect
?>
